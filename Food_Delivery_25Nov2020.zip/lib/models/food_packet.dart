import 'package:flutter/material.dart';

class FoodPacket {
  int id;
  String packetSize;

  FoodPacket({
    @required this.id,
    @required this.packetSize,
  });
}
