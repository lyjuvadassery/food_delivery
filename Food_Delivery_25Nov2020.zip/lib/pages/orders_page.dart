import 'package:flutter/material.dart';

class OrdersPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
        child: Text(
          'Orders Page',
          style: TextStyle(
            fontSize: 20.0,
          ),
        ),
      ),
    );
  }
}
