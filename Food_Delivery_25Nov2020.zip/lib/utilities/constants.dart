import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

const kSelectedRedColor = Color(0xFFFF8888);
const kOrange = Color(0xFFF08F7F);
const kDarkGrey = Color(0xFF969696);
const kDarkGrey2 = Color(0xFF777777);
const kDarkGrey3 = Color(0xFF272727);
const kUnselectedGreyColor = Color(0xFFCDCDCD);
const kUnselectedLightGrey = Color(0xFFC9C9C9);
const kMediumGrey = Color(0xFFEEEEEE);
const kMediumGreen = Color(0xFF00DD00);
const kDarkGreen = Color(0xFF007700);

// const kHeadingTextStyle = TextStyle(
//   fontSize: 20,
//   fontWeight: FontWeight.w800,
// );
